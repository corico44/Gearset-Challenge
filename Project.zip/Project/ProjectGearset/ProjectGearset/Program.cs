﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.xml;
using static iTextSharp.text.Font;


namespace Prueba2
{
    class Program
    {
        static void Main(string[] args)
        {

            string path = @"C:\Gearset-Challenge-master\input.txt";
            string[] lines = File.ReadAllLines(path); //Reading the text document input.txt
            int n = lines.Length;

            Write_Pdf(lines, n);
        }

        //Controls the writing in the PDF
        static public void Write_Pdf(string[] lines, int tam)
        {

            FileStream fs = new FileStream(@"C:\Gearset-Challenge-master\output.pdf", FileMode.Create); //Creation of the PDF
            Document doc = new Document();
            PdfWriter pw = PdfWriter.GetInstance(doc, fs);

            doc.SetMargins(100f, 55f, 50f, 50f); //Size of document margins          
            doc.Open();

            Handling_Instructions(doc, lines, tam);
            
            doc.Close();
        }

        //It deals with the instructions and actions that must be carried out according to the input
        static public void Handling_Instructions(Document doc, string[] lines, int tam)
        {
            int num_indent = 0;
            int counter_indent = 0; //Actual value of the indentation
            bool is_first = true;
            bool is_title = false;

            Paragraph p = new Paragraph();
            To_Normal(p); //Default
            Paragraph_NoFill(p); //Default

            for (int i = 0; i < tam; ++i)
            {

                if (lines[i] == ".nofill")
                {
                    doc.Add(p);
                    p = new Paragraph();
                    To_Normal(p);
                    Paragraph_NoFill(p);

                }

                else if (lines[i] == ".fill")
                {
                    Paragraph_Fill(p);
                }

                else if (lines[i] == ".large")
                {
                    To_Large(p);
                    is_title = true;
                }

                else if (lines[i] == ".regular" || lines[i] == ".normal")
                {
                    To_Normal(p);
                }

                else if (lines[i] == ".italics")
                {
                    To_Italics(p);
                }

                else if (lines[i] == ".bold")
                {
                    To_Bold(p);
                }

                else if (lines[i] == ".paragraph")
                {
                    doc.Add(p);
                    p = new Paragraph();
                    To_Normal(p);
                    Paragraph_NoFill(p);
                    if (lines[i - 1].StartsWith("."))
                    {
                        //If there is another instruction before the creation of the paragraph, 
                        //the "Instruction_Before" function is executed
                        Instruction_Before(lines[i - 1], p);
                    }

                }

                else if (lines[i].StartsWith(".indent"))

                {
                    int num_input = Convert.ToInt32(lines[i].Substring(8, 2));

                    if (is_first) //First time using ".indent"
                    {
                        num_indent = num_indent + num_input;
                        p.IndentationLeft = num_indent * 20;
                        counter_indent = num_indent;
                        doc.Add(new Paragraph("\n"));
                    }

                    else
                    {
                        doc.Add(p);
                        p = new Paragraph();
                        To_Normal(p);
                        Paragraph_NoFill(p);
                        doc.Add(new Paragraph("\n"));
                        if (counter_indent + num_input == 0)
                        //If the total sum with the new indentation value is 0
                        {
                            num_indent = 0;
                            counter_indent = num_indent;
                        }

                        else
                        {
                            num_indent = (counter_indent + num_input) * 20;
                            counter_indent = num_indent / 20;

                        }

                        p.IndentationLeft = num_indent;
                    }
                    is_first = false;
                }

                else if (!lines[i].StartsWith("."))
                {
                    p.Add(lines[i]);
                    if (is_title)
                    {
                        p.Add(new Paragraph("\n")); //Line break
                        is_title = false; //There is only one title at the beginning of the document
                    }
                    p.SetLeading(0f, 1.5f);
                }
            }
            doc.Add(p);
        }

        //Justify the paragraph
        static public void Paragraph_Fill(Paragraph p)
        {
            p.Alignment = Element.ALIGN_JUSTIFIED;
        }

        //Remove the justification of the paragraph
        static public void Paragraph_NoFill(Paragraph p)
        {
            p.Alignment = Element.ALIGN_LEFT;
        }

        //Change the paragraph font to bold
        static public void To_Bold(Paragraph p)
        {
            Font bold = new Font(FontFamily.HELVETICA, 11, Font.BOLD);
            p.Font = bold;
        }

        //Change the paragraph font to default
        static public void To_Normal(Paragraph p)
        {
            Font normal = new Font(FontFamily.HELVETICA, 11, Font.NORMAL);
            p.Font = normal;
        }

        //Change the paragraph font to italics
        static public void To_Italics(Paragraph p)
        {
            Font italic = new Font(FontFamily.HELVETICA, 11, Font.ITALIC);
            p.Font = italic;
        }

        //Turn the paragraph into a title
        static public void To_Large(Paragraph p)
        {
            Font large = new Font(FontFamily.HELVETICA, 22);
            p.Font = large;
        }

        //The font is changed according to the value of "instruction"
        static public void Instruction_Before(string instruction, Paragraph p)
        {
            if (instruction == ".bold") To_Bold(p);
            else if (instruction == ".italics") To_Italics(p);
        }
    }
}
